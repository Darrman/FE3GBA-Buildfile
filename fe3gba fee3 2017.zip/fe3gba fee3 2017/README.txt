FIRE EMBLEM: MYSTERY OF THE EMBLEM GBA
FEE3 2017 Version, by Darrman

This is an FE8 patch, and must be applied to an FE8 rom. This is heavily WIP, and any maps you see are not intended for the final release. A save file of Chapter 3 has been included, but if this project is chosen for a stream I recommend starting a new game from Chapter 1. Gameplay halts after Chapter 5.

CREDITS:
Hacking: Darrman
Mapping: Darrman
Portraits: Alusq for the good ones, Darrman for the awful cutoffs
ASM stuff: Tequila and Circleseverywhere for general QoL stuff, Venno for star shard growth hack, Crazycolorz for dismounting.
Script: The original FE3 fan translation, where VincentASM and RPGuy did their thing. But there's no Kris to deal with!
Special Thanks: Shouzou Kaga and company, for making the original game.
The FEU regulars, for dealing with all of my shenagains and grouching about names.

Enjoy! - Darrman